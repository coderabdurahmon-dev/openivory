// File: script.js
// Course Database
const courseDatabase = {
    // Graduate
    // Graduate
    // Graduate

    // MiM Courses
    "mim_mit_1": {
        id: "mim_mit_1",
        title: "Strategic Management",
        university: "MIT Sloan School of Management",
        field: "Master in Management",
        videoUrl: "https://www.youtube.com/embed/3X-Vhhs35lA",
        description: "This course explores advanced frameworks for competitive strategy and organizational alignment. Students will learn how to analyze competitive environments, develop sustainable competitive advantages, and align organizational structures with strategic objectives. The course includes case studies from technology, manufacturing, and service industries.",
        professor: {
            name: "Dr. Vinay Sharma",
            bio: "Development of Low-Cost Energy-based Value Chain through a Briquette Machine Innovation This machine is being developed as a tool for propelling Social entrepreneurship where villagers living in and around the forest area may adopt briquette making from the harmful Pine needles and may earn a livelihood option. This will also save the forest of Uttarakhand from the disaster of forest fire as the forest floor will be devoid of inflammable dry and Pine needles spread over a large area.",
            image: "images/mim_mit_1.png",
            achievements: [
                "President of India, India National Award to Teachers(2024)",
                "AIMS International, India Outstanding Management Researcher Award(2024)",
                "Sugar Technologists Association of India Noël Deerr Gold Medal(2013)"
            ]
        },
        duration: "28 hours",
        lectures: 60,
        level: "Graduate"
    },
    "mim_mit_2": {
        id: "mim_mit_2",
        title: "Leadership in Organizations",
        university: "MIT Sloan School of Management",
        field: "Master in Management",
        videoUrl: "https://www.youtube.com/embed/0tLXhbovqyA",
        description: "Developing leadership capabilities for complex organizational environments. This course examines leadership theories, emotional intelligence, change management, and team dynamics in modern organizations. Participants will engage in simulations and case analyses to develop practical leadership skills.",
        professor: {
            name: "Dr. Tara Swart",
            bio: "Faculty Director in the Neuroscience for Business online short course from the MIT Sloan School of Management, discusses how a model based on the brain’s plasticity can help organizations pivot.",
            image: "images/mim_mit_2.png",
            achievements: [
                "She serves as a Senior Lecturer at the MIT Sloan School of Management and a visiting senior lecturer at King’s College London",
                "She holds a PhD in Neuropharmacology and a Bachelor of Medicine'",
                "She also teaches at Oxford Saïd Business School"
            ]
        },
        duration: "10 hours",
        lectures: 6,
        level: "Graduate"
    },
    "mim_harvard_1": {
        id: "mim_harvard_1",
        title: "Business Strategy",
        university: "Harvard Business School",
        field: "Master in Management",
        videoUrl: "https://www.youtube.com/embed/QZs-IS4yhOU",
        description: "Case-based approach to strategic decision making in competitive markets. This course uses the famous Harvard case method to examine real-world business challenges and strategic decisions. Students will analyze cases from various industries and develop strategic recommendations.",
        professor: {
            name: " Michael E. Porter",
            bio: "Michael Porter is an economist, researcher, author, advisor, speaker and teacher. Throughout his career at Harvard Business School, he has brought economic theory and strategy concepts to bear on many of the most challenging problems facing corporations, economies and societies, including market competition and company strategy, economic development, the environment, and health care.",
            image: "images/mim_harvard_1.png",
            achievements: [
                "Porter's Five Forces: A framework for analyzing industry structure and attractiveness based on five competitive forces: threat of new entrants, bargaining power of suppliers, bargaining power of buyers, threat of substitute products, and rivalry among existing competitors",
                "Generic Strategies: He identified four basic ways a company can achieve a competitive advantage: Cost Leadership, Differentiation, Cost Focus, and Differentiation Focus",
                "Political Innovation: In 2020, he co-authored The Politics Industry, applying his competitive frameworks to analyze why the U.S. political system is failing to deliver results for citizens"
            ]
        },
        duration: "15 hours",
        lectures: 10,
        level: "Graduate"
    },
    "mim_harvard_2": {
        id: "mim_harvard_2",
        title: "Negotiation Mastery",
        university: "Harvard Business School",
        field: "Master in Management",
        videoUrl: "https://www.youtube.com/embed/EeuL4dk43NI",
        description: "Negotiation is an essential skill in today's dynamic workplace. In this course from Harvard Business School Professor Michael Wheeler, you will learn to understand negotiation dynamics, craft an effective negotiation strategy, and secure maximum value for your organization and yourself",
        professor: {
            name: "Professor Michael Wheeler",
            bio: "Michael Porter is an economist, researcher, author, advisor, speaker and teacher. Throughout his career at Harvard Business School, he has brought economic theory and strategy concepts to bear on many of the most challenging problems facing corporations, economies and societies, including market competition and company strategy, economic development, the environment, and health care.",
            image: "images/mim_harvard_2.png",
            achievements: [
                "Having taken a double first in English at Magdalene College Cambridge and a doctorate at University College London, Michael became Lecturer and later Professor of English Literature at Lancaster University",
                "He was co-Director of Chawton House Library and Professor (now Visiting Professor) at the University of Southampton",
                "Michael was awarded an honorary doctorate by the University of Surrey. He and David Carroll were joint general editors of the Longman Literature in English series (30 vols.)"
            ]
        },
        duration: "15 hours",
        lectures: 10,
        level: "Graduate"
    },

    // Economics Courses
    "econ_yale_1": {
        id: "econ_yale_1",
        title: "Financial Markets",
        university: "Yale Department of Economics",
        field: "Economics & Finance",
        videoUrl: "https://www.youtube.com/embed/WQui_3Hpmmc",
        description: "Professor Shiller provides a description of the course, including its general theme, the relevant textbooks, as well as the interplay of his course with Professor Geanakoplos's course 'Economics 251--Financial Theory.' Finance, in his view, is a pillar of civilized society, dealing with the allocation of resources through space and time in order to manage big and important risks. After talking about finance as an occupation, he emphasizes the moral imperative to use wealth for the purposes of philanthropy, in the spirit of Andrew Carnegie, but also of Bill Gates and Warren Buffett. Subsequently, he introduces the guest speakers David Swensen, Yale University's chief investment officer, Maurice 'Hank' Greenberg, former Chief Executive Officer (CEO) at American International Group (AIG) and current CEO of C.V. Starr & Co. and of Starr International, and Laura Cha, former vice chair of the China Securities Regulatory Commission, member of the Executive Council of Hong Kong and of the government of the People's Republic of China, and director of the Hong Kong Shanghai Banking Corporation (HSBC). Finally, he concludes with a description of the topics to be discussed in each lecture.",
        professor: {
            name: "Professor Robert James Shiller",
            bio: "PhD, Massachusetts Institute of Technology, 1972.  Robert J. Shiller is Sterling Professor Emeritus of Economics, Department of Economics and Cowles Foundation for Research in Economics, Yale University, and Professor of Finance and Fellow at the International Center for Finance, Yale School of Management. He received his B.A. from the University of Michigan in 1967 and his Ph.D. in economics from the Massachusetts Institute of Technology in 1972. He has written on financial markets, financial innovation, behavioral economics, macroeconomics, real estate, and statistical methods, and on public attitudes, opinions, and moral judgments regarding markets.",
            image: "images/econ_yale_1.png",
            achievements: [
                "Global Economy Prize, Kiel Institute for the World Economy, the City of Kiel and the Schleswig-Holstein Chamber of Commerce, 2018",
                "Chicago Mercantile Exchange Group-Mathematical Sciences Research Institute Prize in Innovative Quantitative Applications, 2012",
                "Paul A. Samuelson Award for Macro Markets: Creating Institutions for Managing Society's Largest Economic Risks (Oxford University Press), 1996, and for Animal Spirits, 2009 "
            ]
        },
        duration: "20 hours",
        lectures: 15,
        level: "Graduate"
    },
    "econ_yale_2": {
        id: "econ_yale_2",
        title: "Behavioral Economics",
        university: "Yale Department of Economics",
        field: "Behavioral Economics",
        videoUrl: "https://www.youtube.com/embed/4qG4of5UAj4",
        description: "Professor Shiller provides a description of the course, including its general theme, the relevant textbooks, as well as the interplay of his course with Professor Geanakoplos's course 'Economics 251--Financial Theory.' Finance, in his view, is a pillar of civilized society, dealing with the allocation of resources through space and time in order to manage big and important risks. After talking about finance as an occupation, he emphasizes the moral imperative to use wealth for the purposes of philanthropy, in the spirit of Andrew Carnegie, but also of Bill Gates and Warren Buffett. Subsequently, he introduces the guest speakers David Swensen, Yale University's chief investment officer, Maurice 'Hank' Greenberg, former Chief Executive Officer (CEO) at American International Group (AIG) and current CEO of C.V. Starr & Co. and of Starr International, and Laura Cha, former vice chair of the China Securities Regulatory Commission, member of the Executive Council of Hong Kong and of the government of the People's Republic of China, and director of the Hong Kong Shanghai Banking Corporation (HSBC). Finally, he concludes with a description of the topics to be discussed in each lecture.",
        professor: {
            name: "Professor Robert James Shiller",
            bio: "Professor Novemsky is Professor of Marketing in the Yale School of Management and has an appointment as Professor of Psychology in the Department of Psychology at Yale University. He is an expert in the psychology of judgment and decision-making, an area that overlaps heavily with behavioral economics and consumer behavior. He has published articles in leading marketing and psychology journals on topics that include: how people made judgments and decisions based on the information in front of them, how they know what they like, how the way they frame decisions affects the choices they make, how they choose and evaluate gifts, how their goals influence their behavior and other topics in judgment and decision-making",
            image: "images/econ_yale_2.png",
            achievements: [
                "Leadership Awards: In 2023, he received the Yale Alumni Leadership Award for his innovative leadership and service as an alumni volunteer.",
                "World Economic Forum (WEF) Leadership: He previously served as a Global Leadership Fellow at the WEF, where he managed key agreements for private and public sector stakeholders and led the Global Future Council on Mobility",
                "Influential Research: Dr. Novemsky is a leading expert in the psychology of judgment and decision-making. His research, which has been cited hundreds of times, explores how consumers interpret information, frame decisions, and set goal targets"
            ]
        },
        duration: "20 hours",
        lectures: 15,
        level: "Graduate"
    },
    // Engineering Courses
    "eng_stanford_1": {
        id: "eng_stanford_1",
        title: "Artificial Intelligence",
        university: "Stanford School of Engineering",
        field: "Engineering",
        videoUrl: "https://www.youtube.com/embed/EVPcfyJWREY",
        description: "Advanced AI algorithms, machine learning, and neural networks. This course covers the theoretical foundations and practical applications of artificial intelligence. Topics include supervised and unsupervised learning, deep neural networks, natural language processing, and ethical considerations in AI.",
        professor: {
            name: "Percy Liang",
            bio: "Percy Liang is a renowned computer scientist and associate professor at Stanford University, where he serves as the director of the Center for Research on Foundation Models (CRFM). His work is at the forefront of artificial intelligence, specifically focusing on making large-scale AI models more transparent, robust, and accessible",
            image: "images/eng_stanford_1.png",
            achievements: [
                "Presidential Early Career Award for Scientists and Engineers (2019)",
                "IJCAI Computers and Thought Award (2016)",
                "Graduate fellowships: NSF, NDSEG, GAANN, Siebel Scholar",
                "Programming contests: 2nd place at 2002 ACM ICPC World Finals, silver medalist at IOI 2000",
                
            ]
        },
        duration: "25 hours",
        lectures: 18,
        level: "Graduate"
    },
    // Medicine Courses
    "med_harvard_1": {
        id: "med_harvard_1",
        title: "Genetics and Genomics",
        university: "Harvard Medical School",
        field: "Health & Medicine",
        videoUrl: "https://www.youtube.com/embed/jEJp7B6u_dY",
        description: "Advanced study of genetic mechanisms and genomic technologies. This course explores the molecular basis of genetics, genome sequencing technologies, gene editing (CRISPR), and personalized medicine. Clinical applications and ethical considerations are emphasized throughout.",
        professor: {
            name: "David A. Sinclair",
            bio: "David A. Sinclair, an Australian-American biologist, is a renowned Harvard Medical School genetics professor known for pioneering research on aging and longevity, focusing on epigenetics, sirtuins, and NAD+ metabolism, aiming to slow aging and prevent age-related diseases through therapies like cellular reprogramming and small molecules; he's a bestselling author, co-founder of numerous biotech companies, and a prominent figure in health and science media",
            image: "images/med_harvard_1.png",
            achievements: [
                "Aging Research: Pioneered research into sirtuins and the 'information theory of aging,' suggesting aging is a loss of epigenetic information that can be reversed",
                "Biotechnology Entrepreneur: Co-founded numerous companies, including Sirtris (acquired by GSK), MetroBiotech, Life Biosciences, EdenRoc Sciences, and Tally Health, focusing on developing anti-aging therapies",
                "Lifespan: Wrote the New York Times bestseller Lifespan: Why We Age – And Why We Don't Have To, making complex aging science accessible",
                "Scientific Leadership: Served as Founding Director of Harvard's Glenn Center for Biology of Aging Research; co-founder & co-chief editor of the journal Aging",
                "Patents & Publications: Holds over 50 patents and has published hundreds of highly cited research papers",
                "Media & Influence: Featured on 60 Minutes, named to TIME Magazine's 100 Most Influential People, hosts the Lifespan podcast, and received the NIH Director's Pioneer Award"
            ]   
        },
        duration: "18 hours",
        lectures: 12,
        level: "Graduate"
    },

    // Undergraduate Programs
    // Undergraduate Programs
    // Undergraduate Programs

    // Harvard Businnes
   
    "bus_harvard_1": {
        id: "bus_harvard_1",
        title: "Businnes Management Harvard",
        university: "Harvard",
        field: "Undergraduate",
        videoUrl: "https://www.youtube.com/embed/RwyJzi56nSQ",
        description: "An understanding of finance is essential to success in today’s business environment. In this course from Harvard Business School Professor Mihir Desai, you will learn not only the theories of finance and how to interpret the numbers, but also how to apply that knowledge to making smarter financial decisions and how to communicate those decisions to key stakeholders.",
        professor: {
            name: "Professor Mihir Desai",
            bio: "Professor Mihir A. Desai is a distinguished Indian-American finance expert, holding the Mizuho Financial Group Professorship at Harvard Business School (HBS) and Harvard Law School, known for his work in tax policy, international finance, and corporate finance, with major contributions including advising Congress, authoring influential books like The Wisdom of Finance, and extensive research published in top journals",
            image: "images/bus_harvard_1.png",
            achievements: [
                "Harvard Faculty: Mizuho Financial Group Professor of Finance (HBS) & Professor (HLS)",
                "Research: Focuses on tax policy's impact on finance, corporate governance, international capital, and firm investment",
                "Publications: Articles in leading journals (AER, QJE, JFE) and books like The Wisdom of Finance and How Finance Works",
                "Policy Influence: Testified before U.S. Congress (Senate Finance & House Ways & Means) on tax policy",
                "Advisory Roles: Consults for major corporations and government bodies",
                "Teaching: Develops & teaches finance, tax, & entrepreneurship courses at Harvard, earning teaching awards",
                "NBER: Research Associate in Public Economics & Corporate Finance; former Co-Director of NBER's India Program",
            ]
        },
        duration: "8 hours",
        lectures: 5,
        level: "UnderGraduate"
    },
    // MIT economics
    "econ_mit_1": {
        id: "econ_mit_1",
        title: "MIT Department of Economics",
        university: "MIT",
        field: "Undergraduate",
        videoUrl: "https://www.youtube.com/embed/8ssjKR7nNck",
        description: "Prof. Gruber introduces the class by explaining microeconomics as the study of individuals and firms who make themselves as well off as possible in a world full of scarcity. He then explains the core concepts of supply and demand. Keywords: microeconomics, scarcity, constrained optimization, supply and demand ",
        professor: {
            name: "Professor Jonathan Gruber",
            bio: "Dr. Jonathan Gruber is the Ford Professor of Economics and the Chairman of the Economics Department at the Massachusetts Institute of Technology, where he has taught since 1992. He is also the former Director of the Health Care Program at the National Bureau of Economic Research, and the former President of the American Society of Health Economists. He is a member of the Institute of Medicine, the American Academy of Arts and Sciences, the National Academy of Social Insurance, and the Econometric Society. He has published more than 180 research articles, has edited six research volumes, and is the author of Public Finance and Public Policy, a leading undergraduate text in its 7th edition, Health Care Reform, a graphic novel, and Jump-Starting America: How Breakthrough Science Can Revive Economic Growth and the American Dream (with Simon Johnson). In 2006 he received the American Society of Health Economists Inaugural Medal for the best health economist in the nation aged 40 and under",
            image: "images/econ_mit_1.png",
            achievements: [
                "Guggenheim Fellowship (2020)",
                "President of the American Society of Health Economists (2016-2018)",
                "Director of National Bureau of Economic Research Program on Health Care (2009-2019)",
                "Named “One of the Top 25 Most Innovative and Practical Thinkers of Our Time” by Slate Magazine(2011)",
                "Inaugural Medal for Best Health Economist Age Forty and Under, American Society of Health Economists(2006)",
            ]
        },
        duration: "18 hours",
        lectures: 12,
        level: "UnderGraduate"
    },
    // Engineering Stanford School
    "eng_stanford_ug_1": {
        id: "eng_stanford_ug_1",
        title: "Stanford School of Engineering",
        university: "Stanford",
        field: "Undergraduate",
        videoUrl: "https://www.youtube.com/embed/OQQ-W_63UgQ",
        description: "Lecture 1 introduces the concept of Natural Language Processing (NLP) and the problems NLP faces today. The concept of representing words as numeric vectors is then introduced, and popular approaches to designing word vectors are discussed.Key phrases: Natural Language Processing. Word Vectors. Singular Value Decomposition. Skip-gram. Continuous Bag of Words (CBOW). Negative Sampling. Hierarchical Softmax. Word2Vec. Natural Language Processing with Deep Learning. Instructors: Chris Manning, Richard Socher. Natural language processing (NLP) deals with the key artificial intelligence technology of understanding complex human language communication. This lecture series provides a thorough introduction to the cutting-edge research in deep learning applied to NLP, an approach that has recently obtained very high performance across many different NLP tasks including question answering and machine translation. It emphasizes how to implement, train, debug, visualize, and design neural network models, covering the main technologies of word vectors, feed-forward models, recurrent neural networks, recursive neural networks, convolutional neural networks, and recent models involving a memory component.",
        professor: {
            name: "Christopher D. Manning",
            bio: " Christopher D. Manning is a computer scientist and linguist specializing in Natural Language Processing (NLP) and Artificial Intelligence. He is the Thomas M. Siebel Professor in Machine Learning at Stanford University, where he leads the Stanford NLP group. He is also an associate director of the Stanford Institute for Human-Centered Artificial Intelligence (HAI) and a venture partner at AIX Ventures. ",
            image: "images/eng_stanford_un_1.png",
            achievements: [
                "A pioneer in applying Deep Learning to NLP, Manning is recognized for his work on Tree Recursive Neural Networks and neural network dependency parsing",
                "He founded the Stanford NLP group and contributed to open-source software like Stanford CoreNLP and Stanza",
                "He has been elected to the National Academy of Engineering and the American Academy of Arts and Sciences (2025)",
                "Awards include the 2024 IEEE John von Neumann Medal and three ACL Test of Time Awards",
                "Manning served as President of the Association for Computational Linguistics (ACL) in 2015 and is a Fellow of ACM, AAAI, and ACL. He has co-authored influential textbooks and his online course CS224N is widely used"
            ]
        },
        duration: "25 hours",
        lectures: 15,
        level: "UnderGraduate"
    },

    // AP SAT
    // AP SAT
    // AP SAT

    // SAT reading
    "sat_reading_1": {
        id: "sat_reading_1",
        title: "SAT Reading Mastery",
        videoUrl: "https://www.youtube.com/embed/r_0QHkFg8L8",
        description: "Hayden Rhodea is a prominent educational content creator and SAT expert known for his high-performing prep courses and social media presence. As of 2026, he has established himself as a leading voice in college admissions testing, particularly focusing on the Digital SAT",
        professor: {
            name: "Teacher Hayden Rhodea SAT",
            bio: "Development of Low-Cost Energy-based Value Chain through a Briquette Machine Innovation This machine is being developed as a tool for propelling Social entrepreneurship where villagers living in and around the forest area may adopt briquette making from the harmful Pine needles and may earn a livelihood option. This will also save the forest of Uttarakhand from the disaster of forest fire as the forest floor will be devoid of inflammable dry and Pine needles spread over a large area.",
            image: "images/sat_reading_1.png",
            achievements: [
                "Background: He is a high-scoring individual himself, having recorded a perfect 800 on the SAT Math section and a 1590 overall",
                "Digital SAT Authority: He is widely recognized for his 'Speedrun' videos and comprehensive walkthroughs of Digital SAT practice tests, which have garnered millions of views",
                "Substantial Following: By 2026, his YouTube channel 'Hayden Rhodea SAT' has surpassed 188,000 subscribers, making it a primary resource for students worldwide",
                "90-Day Prep Course: He developed a popular free 90-day SAT prep schedule that has been used by thousands of students to increase their scores by hundreds of points",
                "Academic Recognition: He has been recognized for his contributions to student success, including winning the Dr. Pepper Tuition Giveaway scholarship in 2021",
            ]
        },
        duration: "10 hours",
        lectures: 8,
        level: "For students"
    },
    // SAT Math
    "sat_math_1": {
        id: "sat_math_1",
        title: "SAT Math Intensive",
        videoUrl: "https://www.youtube.com/embed/j1pDk3rBPmc",
        description: "Algebra is the cornerstone of the SAT Math section. In this focused lecture, we dive deep into non-linear functions, quadratic equations, and polynomial operations. Designed for students aiming for a score of 700+, this video simplifies complex theories into actionable steps",
        professor: {
            name: " Robert Brundage",
            bio: "As of 2026, several prominent individuals named Robert Brundage have made significant contributions in the fields of law and education. Professional Focus: Over 30 years of experience defending major manufacturers in motor vehicle and railroad sectors, setting key product-liability precedents in California. Education: Earned a B.A. from Harvard College (magna cum laude) and a J.D. from the University of Michigan Law School",
            image: "images/sat_math_1.png",
            achievements: [
                "2025 Yancey Award: Won the International Association of Defense Counsel's (IADC) Yancey Award for excellence in legal writing for his article on federal standing",
                "Leadership: Served four terms as Chair of the IADC Appellate Practice Committee",
                "Certification: Certified as an appellate specialist by the State Bar of California Board of Legal Specialization",
                "Legislative Influence: Serves as counsel to the Missouri Pork and Cattlemen’s Associations, lobbying for favorable agricultural laws"
            ]
        },
        duration: "5 hours",
        lectures: 1,
        level: "For students"
    },
    // AP cal
    "ap_calc_1": {
        id: "ap_calc_1",
        title: "AP Calculus AB/BC",
        videoUrl: "https://www.youtube.com/embed/OWh6ZIsop9M",
        description: "10 hours of AP Calc AB review and AP Calc BC review. We go over 55 AP Calc AB/BC FRQ problems and their complete solutions. Organized by topic. Pro tip: problem numbers above 2 (as in: 3 to 6) generally do not allow calculators",
        professor: {
            name: "Wrath of Math",
            bio: "The creator behind 'Wrath of Math' began the channel while studying mathematics in college at the age of 18. With over a decade of experience in digital education, the creator identifies as a math teacher who also incorporates music (specifically rapping about math) into the learning experience. The brand's philosophy often centers on sharing an enthusiasm for the subject and providing clear, concise explanations of complex topics ranging from basic algebra to advanced abstract math",
            image: "images/ap_calc_1.png",
            achievements: [
                "Massive Educational Reach: Accumulated over 35 million views and built a community of more than 353,000 subscribers",
                "Extensive Content Library: Produced a library of over 2,000 instructional videos covering diverse topics such as graph theory, algebra, and calculus",
                "Multimodal Teaching: Successfully integrated music and memes into math education to reach younger audiences, including viral content and' math raps",
                "Advanced Educational Resources: Beyond free YouTube content, the platform offers structured math courses for deeper dives into specific mathematical fields",
            ]
        },
        duration: "5 hours",
        lectures: 1,
        level: "For students"
    },
    // AP Chemist
    "ap_chem_1": {
        id: "ap_chem_1",
        title: "AP Chemistry",
        videoUrl: "https://www.youtube.com/embed/YfOwH4RW4HM",
        description: "During this live AP Chemistry Review Session, Mr. Farabaugh will present a total of 30 multiple choice questions for you to practice with that cover chemistry content from all 9 Units in the AP Chemistry Course and Exam Description (CED) ",
        professor: {
            name: "Mr. Farabaugh",
            bio: "Currently a science teacher at Albemarle High School in Charlottesville, Virginia, Michael Farabaugh is widely recognized for his contributions to Advanced Placement (AP) Chemistry education",
            image: "images/ap_chem_1.png",
            achievements: [
               "AP Chemistry Leadership: Served on the AP Chemistry Test Development Committee from 2020 to 2024 and acts as an AP Chemistry Reader and Consultant",
               "Educational Outreach: Operates a popular YouTube channel (@mrfarabaugh) with over 20,000 subscribers, providing detailed instructional videos that support chemistry students and teachers globally",
            ]
        },
        duration: "13 hours",
        lectures: 9,
        level: "For students"
    },
};
// Player Page Functionality
function loadCoursePlayer() {
    console.log('loadCoursePlayer called');
    console.log('Current pathname:', window.location.pathname);
    console.log('Current search:', window.location.search);
    
    // Only run on player.html
    if (!window.location.pathname.includes('player.html')) {
        console.log('Not on player.html, exiting');
        return;
    }
    
    // Get course ID from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('id');
    
    console.log('Course ID from URL:', courseId);
    
    // If no course ID, redirect to home
    if (!courseId) {
        console.log('No course ID found, redirecting to home');
        window.location.href = 'index.html';
        return;
    }
    
    // Get course data from database
    const course = courseDatabase[courseId];
    
    console.log('Course found:', course);
    
    // If course not found, redirect to home
    if (!course) {
        console.log('Course not found in database, redirecting to home');
        window.location.href = 'index.html';
        return;
    }
    
    // Update page title
    document.title = `${course.title} | OpenIvory`;
    
    console.log('Updating page elements...');
}   
    // ... qolgan kod o'zgarishsiz qoladi
// Player Page Functionality
function loadCoursePlayer() {
    // Only run on player.html
    if (!window.location.pathname.includes('player.html')) return;
    
    // Get course ID from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('id');
    
    // If no course ID, redirect to home
    if (!courseId) {
        window.location.href = 'index.html';
        return;
    }
    
    // Get course data from database
    const course = courseDatabase[courseId];
    
    // If course not found, redirect to home
    if (!course) {
        window.location.href = 'index.html';
        return;
    }
    
    // Update page title
    document.title = `${course.title} | OpenIvory`;
    
    // Update course content
    const courseTitle = document.getElementById('course-title');
    const courseUniversity = document.getElementById('course-university');
    const courseField = document.getElementById('course-field');
    const videoFrame = document.getElementById('course-video');
    const courseDescription = document.getElementById('course-description');
    const professorName = document.getElementById('professor-name');
    const professorBio = document.getElementById('professor-bio');
    const professorImage = document.getElementById('professor-image');
    const professorAchievements = document.getElementById('professor-achievements');
    
    if (courseTitle) courseTitle.textContent = course.title;
    if (courseUniversity) courseUniversity.textContent = course.university;
    if (courseField) courseField.textContent = course.field;
    if (videoFrame) videoFrame.src = course.videoUrl;
    if (courseDescription) courseDescription.textContent = course.description;
    
    // Update professor information
    if (professorName) professorName.textContent = course.professor.name;
    if (professorBio) professorBio.textContent = course.professor.bio;
    if (professorImage) {
        professorImage.src = course.professor.image;
        professorImage.alt = `Professor ${course.professor.name}`;
    }
    
    // Update professor achievements
    if (professorAchievements && course.professor.achievements) {
        professorAchievements.innerHTML = '';
        course.professor.achievements.forEach(achievement => {
            const li = document.createElement('li');
            li.textContent = achievement;
            professorAchievements.appendChild(li);
        });
    }
    
    // Update course metadata
    const courseDuration = document.getElementById('course-duration');
    const courseLectures = document.getElementById('course-lectures');
    const courseLevel = document.getElementById('course-level');
    
    if (courseDuration) courseDuration.textContent = course.duration;
    if (courseLectures) courseLectures.textContent = course.lectures;
    if (courseLevel) courseLevel.textContent = course.level;
}

// Navigation functionality
function setupNavigation() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close menu when clicking a link
        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }
    
    
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setupNavigation();
    loadCoursePlayer();
    
    // Initialize AOS
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    }
});

// Handle browser back/forward navigation
window.addEventListener('popstate', function() {
    loadCoursePlayer();
});
